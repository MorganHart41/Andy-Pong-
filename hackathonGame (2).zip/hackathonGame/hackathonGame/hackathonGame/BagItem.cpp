/**********************************************************************************
*Project: Hackathon_WSU_2016                                                      *
*Team Name: E=MC^2                                                                *
*Partners: Eugene, Cody, Morgan                                                   *
*Goal: Make An Adventure Style Game. The Purpose Of The Game Is To Grind And      *
*	   Gain Levels In Order To Defeat Bosses And Solve Scenarios. AKA: Survive.   *
*FILE: Charachter.h, This Will Be The Header File For Housing The Charachter Class*
**********************************************************************************/

#include "BagItem.h"

/****************************************************************
						CONSTRUCTOR
*****************************************************************/
BagItem::BagItem(string newName, int newDamage, BagItem *newBagPointer)
{
	Name = newName;
	NextBagItem = newBagPointer;
}

/****************************************************************
					  GETTERS/SETTERS
*****************************************************************/
string BagItem::getName() const
{
	return Name;
}
BagItem *BagItem::getNextBag() const
{
	return NextBagItem;
}
int BagItem::getDamage() const
{
	return damageBoost;
}

void BagItem::setName(string newName)
{
	Name = newName;
}
void BagItem::setNextBag(BagItem *const newNextBag)
{
	NextBagItem = newNextBag;
}
void BagItem::setDamage(int const newDamage)
{
	damageBoost = newDamage;
}